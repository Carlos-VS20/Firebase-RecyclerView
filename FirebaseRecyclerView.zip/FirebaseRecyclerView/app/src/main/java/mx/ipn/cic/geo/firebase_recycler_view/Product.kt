package mx.ipn.cic.geo.firebase_recycler_view

data class Product(val producto: String, val precio: String, val existencia: String) {
    companion object {
        val data
            get() = listOf(
                Product("Disco Duro Seagate 4TB", "6800.67", "SI"),
                Product("Monitor Samsung 27", "4500.89", "SI"),
                Product("Memoria RAM 4GB", "3900.00", "SI"),
                Product("Memoria ROM 4GB", "4900.00", "SI"),
                Product("Memoria RAM 8GB", "8900.00", "SI"),
                Product("Memoria ROM 8GB", "9900.00", "SI"),
                Product("Memoria RAM 16GB", "12900.00", "SI"),
                Product("Memoria ROM 16GB", "13900.00", "SI"),
            )
    }
}

