package mx.ipn.cic.geo.firebase_recycler_view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.controls.ControlsProviderService.TAG
import android.util.Log
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val db = Firebase.firestore

        db.collection("Producto")
            .get()
            .addOnSuccessListener { result ->

                var tmatriz: List<Product> = emptyList()

                for (document in result) {
                    //Log.d(TAG, "${document.id} => ${document.data}")
                    val listProductos: List<Product> = listOf(Product(
                        "${document.data.get("producto")}",
                        "${document.data.get("precio")}",
                        "${document.data.get("existencia")}"))

                    tmatriz += listProductos
                }
                println(tmatriz.size)

                val productList: RecyclerView = findViewById(R.id.recyclerProducts)
                val productAdapter = ProductAdapter()
                productList.adapter = productAdapter
                productAdapter.products = tmatriz

                //init()


            }
            .addOnFailureListener { exception ->
                Log.w(TAG, "Error getting documents.", exception)
            }

        fun init(){

        }

    }
}